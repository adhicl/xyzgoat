//
//  IOSCodePlugin.swift
//  NativeIOSCode
//
//  Created by macbook on 2/8/25.
//

import Foundation
import SwiftUI
import UIKit


class IOSCodePlugin:NSObject {
    static let shared = IOSCodePlugin()
    
    public func objectRotated(x: Float, y: Float, z: Float) {
        print("Object is rotated: \(x), \(y), \(z)")
    }
    
    var runner = RandomIntervalRunner()
    var sparkHandler: ((Float, Float, Float) -> Void)?
    
    public func setupEmitter() {
        runner.start {
            let red = Float.random(in: 0.0...1.0)
            let green = Float.random(in: 0.0...1.0)
            let blue = Float.random(in: 0.0...1.0)
            print("Action executed at \(Date()). Color: \(red) \(green) \(blue)")
            
            // TODO: call the unity code here to trigger the spark
            self.sparkHandler?(red, green, blue)
        }
    }
    
    public func setSparkDelegate(handler: @escaping ((_ r:Float,_ g:Float,_ b:Float) -> Void)){
        self.sparkHandler = handler
    }
    
    public func showNativePage() {
        DispatchQueue.main.async{
            let vc = UIViewController()
            vc.view.backgroundColor = .blue
            if let rootViewController = UIApplication.shared.windows.first?.rootViewController{
                rootViewController.present(vc, animated: true)
            }
        }
    }

}

class RandomIntervalRunner {
    private var timer: Timer?
    
    func start(action: @escaping () -> Void) {
        scheduleNextRun(action: action)
    }
    
    func stop() {
        timer?.invalidate()
        timer = nil
    }
    
    private func scheduleNextRun(action: @escaping () -> Void) {
        let randomInterval = TimeInterval(Int.random(in: 1...5))
        timer = Timer.scheduledTimer(withTimeInterval: randomInterval, repeats: false) { [weak self] _ in
            action()
            self?.scheduleNextRun(action: action) // Schedule the next run
        }
    }
}

let a = IOSCodePlugin()

@_cdecl("NativeIOSCode_objectRotated")
public func NativeIOSCode_objectRotated(x:Float, y:Float, z:Float) {
    a.objectRotated(x: x, y: y, z: z)
}

@_cdecl("NativeIOSCode_setupEmitter")
public func NativeIOSCode_setupEmitter() {
    a.setupEmitter()
}

@_cdecl("NativeIOSCode_setSparkDelegate")
public func NativeIOSCode_setSparkDelegate(handler: @convention(c) @escaping (Float, Float, Float) -> Void) {
    a.setSparkDelegate(handler: handler)
}

@_cdecl("NativeIOSCode_openNativePage")
public func NativeIOSCode_openNativePage() {
    a.showNativePage()
}
